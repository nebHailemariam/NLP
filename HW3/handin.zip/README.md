# NLP

### I have consulted Blessed Guda, I have not employed any outside resource.
